﻿namespace Eras.Domain.Entities.Referrals.Validations;

public sealed record ReferRemissionInput
{
    public required Remission Remission { get; init; }
}
