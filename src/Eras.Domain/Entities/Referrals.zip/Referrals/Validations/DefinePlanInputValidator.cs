﻿
using FluentValidation;

namespace Eras.Domain.Entities.Referrals.Validations;

public sealed class DefinePlanInputValidator : AbstractValidator<DefinePlanInput>
{
    public DefinePlanInputValidator()
    {
        RuleFor(x => x.Remission.Status)
            .NotEqual(RemissionStatus.Concluded)
            .WithMessage("Concluded remissions cannot be modified.");

        RuleFor(x => x.PrimaryStudentId)
            .Must((input, studentId) => input.Remission.HasStudent(studentId))
            .WithMessage("The intervention plan student must belong to the remission.");

        RuleFor(x => x.Diagnosis).NotNull();
        RuleFor(x => x.Objective).NotNull();
    }
}