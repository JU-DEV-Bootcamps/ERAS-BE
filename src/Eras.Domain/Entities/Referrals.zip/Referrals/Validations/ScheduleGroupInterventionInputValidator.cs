﻿
using FluentValidation;

namespace Eras.Domain.Entities.Referrals.Validations;

public sealed class ScheduleGroupInterventionInputValidator : AbstractValidator<ScheduleGroupInterventionInput>
{
    public ScheduleGroupInterventionInputValidator()
    {
        RuleFor(x => x.Remission.Status)
            .Must(status => status is RemissionStatus.InProgress or RemissionStatus.WaitingForProfessional)
            .WithMessage("Interventions can only be created when the remission is being handled.");

        RuleFor(x => x.ParticipantStudentIds)
            .NotEmpty()
            .WithMessage("A group intervention must have at least one participant.");

        RuleFor(x => x.ParticipantStudentIds)
            .Must((input, participants) => participants.All(input.Remission.HasStudent))
            .WithMessage("All participants must belong to the remission.");
    }
}