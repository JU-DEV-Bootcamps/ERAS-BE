﻿namespace Eras.Domain.Entities.Referrals.Validations;

public sealed record ScheduleGroupInterventionInput
{
    public required Remission Remission { get; init; }
    public required InterventionId InterventionId { get; init; }
    public required DateTime DateUtc { get; init; }
    public required InterventionActivity Activity { get; init; }
    public required InterventionArea Area { get; init; }
    public required ProfessionalId ProfessionalId { get; init; }
    public required IReadOnlyCollection<StudentId> ParticipantStudentIds { get; init; }
    public string? Comments { get; init; }
}
