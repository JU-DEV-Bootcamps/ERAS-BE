﻿
using FluentValidation;

namespace Eras.Domain.Entities.Referrals.Validations;

public sealed class ReferRemissionInputValidator : AbstractValidator<ReferRemissionInput>
{
    public ReferRemissionInputValidator()
    {
        RuleFor(x => x.Remission.Status)
            .Equal(RemissionStatus.Created)
            .WithMessage("Only created remissions can be referred.");

        RuleFor(x => x.Remission.AssignedProfessionalId)
            .NotNull()
            .WithMessage("A professional must be assigned before referring.");
    }
}