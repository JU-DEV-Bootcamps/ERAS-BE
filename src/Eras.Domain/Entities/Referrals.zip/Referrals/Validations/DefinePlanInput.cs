﻿namespace Eras.Domain.Entities.Referrals.Validations;

public sealed record DefinePlanInput
{
    public required Remission Remission { get; init; }
    public required StudentId PrimaryStudentId { get; init; }
    public required Diagnosis Diagnosis { get; init; }
    public required Objective Objective { get; init; }
    public string? Notes { get; init; }
}
